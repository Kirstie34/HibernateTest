CREATE PROCEDURE `sp_Employees_SelectAll`()
  BEGIN
SELECT * FROM Employees;

END