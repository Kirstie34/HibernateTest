CREATE VIEW `category sales for 1997` AS
  SELECT
    `product sales for 1997`.`CategoryName`      AS `CategoryName`,
    sum(`product sales for 1997`.`ProductSales`) AS `CategorySales`
  FROM `northwind`.`product sales for 1997`
  GROUP BY `product sales for 1997`.`CategoryName`