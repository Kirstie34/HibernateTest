CREATE VIEW `products by category` AS
  SELECT
    `northwind`.`categories`.`CategoryName`  AS `CategoryName`,
    `northwind`.`products`.`ProductName`     AS `ProductName`,
    `northwind`.`products`.`QuantityPerUnit` AS `QuantityPerUnit`,
    `northwind`.`products`.`UnitsInStock`    AS `UnitsInStock`,
    `northwind`.`products`.`Discontinued`    AS `Discontinued`
  FROM (`northwind`.`categories`
    JOIN `northwind`.`products` ON ((`northwind`.`categories`.`CategoryID` = `northwind`.`products`.`CategoryID`)))
  WHERE (`northwind`.`products`.`Discontinued` <> 1)