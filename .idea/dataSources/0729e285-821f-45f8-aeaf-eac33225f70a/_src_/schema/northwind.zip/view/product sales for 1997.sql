CREATE VIEW `product sales for 1997` AS
  SELECT
    `northwind`.`categories`.`CategoryName`                             AS `CategoryName`,
    `northwind`.`products`.`ProductName`                                AS `ProductName`,
    sum(((((`northwind`.`order details`.`UnitPrice` * `northwind`.`order details`.`Quantity`) *
           (1 - `northwind`.`order details`.`Discount`)) / 100) * 100)) AS `ProductSales`
  FROM (((`northwind`.`categories`
    JOIN `northwind`.`products` ON ((`northwind`.`categories`.`CategoryID` = `northwind`.`products`.`CategoryID`))) JOIN
    `northwind`.`order details`
      ON ((`northwind`.`products`.`ProductID` = `northwind`.`order details`.`ProductID`))) JOIN `northwind`.`orders`
      ON ((`northwind`.`orders`.`OrderID` = `northwind`.`order details`.`OrderID`)))
  WHERE (`northwind`.`orders`.`ShippedDate` BETWEEN '1997-01-01' AND '1997-12-31')
  GROUP BY `northwind`.`categories`.`CategoryName`, `northwind`.`products`.`ProductName`