CREATE VIEW `customer and suppliers by city` AS
  SELECT
    `northwind`.`customers`.`City`        AS `City`,
    `northwind`.`customers`.`CompanyName` AS `CompanyName`,
    `northwind`.`customers`.`ContactName` AS `ContactName`,
    'Customers'                           AS `Relationship`
  FROM `northwind`.`customers`
  UNION SELECT
          `northwind`.`suppliers`.`City`        AS `City`,
          `northwind`.`suppliers`.`CompanyName` AS `CompanyName`,
          `northwind`.`suppliers`.`ContactName` AS `ContactName`,
          'Suppliers'                           AS `Suppliers`
        FROM `northwind`.`suppliers`
  ORDER BY `City`, `CompanyName`